<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
<title>SQL Server Ya</title>
<meta name="keywords" content="sql server, programaci�n, sql, tutorial">
<meta name="description" content="El objetivo de este tutorial 
es presentar los conceptos b�sicos de SQL Server.">
<meta name="author" content="Diego Moisset">
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="principal.css">
<link rel="stylesheet" type="text/css" href="print.css" media="print">
<script type="text/javascript" src="principal.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<style type="text/css">
<!--
.Estilo3 {
	color: #CC6633;
	font-weight: bold;
	font-style: italic;
}

.cuerpotabla {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
    font-style: italic;
}

-->
</style>

</head>
<body>
<div id="container">
  <div id="header">
<table width="100%">
      <tr> 
        <td width="35%">
            <h1>SQL Server Ya</h1>
</td>
<td width="65%">	
</td>
</tr>
</table>	
</div>
<div id="menu">
    <ul id="nav">    
      <li ><a href="index.php?op=1">Curso</a></li>
      <li class="active"><a href="index3.php?op=3">Enlaces</a></li>
      <li ><a href="index2.php?op=2">Acerca de...</a></li> 
    </ul>
</div>
<!-- star of main content -->
  <div id="content"> 
    <p>&nbsp;</p><div class="gradient"> 
<br>
      <p> <b>Foro donde consultar sobre SQL Server.</b> <br>
        <a href="http://www.lawebdelprogramador.com/news/new.php?id=89&texto=SQL">www.lawebdelprogramador.com</a><br>
        <br>
	     <p> <b></b> <br>
        
		
	  <p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
    </div>
  </div> 
<div id="footer">
 <table border="0"><tr valign="top"><td><a  href="http://www.htmlya.com.ar" class="sitiosya">HTML Ya.</a></td> 
  <td><a  href="http://www.cssya.com.ar" class="sitiosya">CSS Ya.</a> </td>
  <td><a  href="http://www.javascriptya.com.ar" class="sitiosya">JavaScript Ya.</a></td> 
  <td><a  href="http://www.dhtmlya.com.ar" class="sitiosya">DHTML Ya.</a> </td>
  <td><a  href="http://www.phpya.com.ar" class="sitiosya">PHP Ya.</a></td>
  <td><a  href="http://www.mysqlya.com.ar" class="sitiosya">MySQL Ya.</a></td>
  <td><a  href="http://www.ajaxya.com.ar" class="sitiosya">AJAX Ya.</a></td></tr>
  <tr><td colspan="4"></td>
  <td><a  href="http://www.aspya.com.ar" class="sitiosya">ASP Ya.</a></td>
  <td><a  href="http://www.sqlserverya.com.ar" class="sitiosya">SQL Server Ya.</a></td>
    <td></td></tr>
  <tr><td colspan="4"></td>
  <td><a  href="http://pythonya.appspot.com" class="sitiosya">Python Ya.</a></td>
  <td></td>
  <td></td></tr>		
  </table>
</div> <!--close footer -->

</div> <!-- close container -->
</body>
</html>