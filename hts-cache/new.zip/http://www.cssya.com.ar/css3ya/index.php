<!doctype html>
<html>
<head>
    <title>CSS3 Ya</title>
    <link href="estilos.css" rel="stylesheet">
    <link href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/smoothness/jquery-ui.css' rel='stylesheet'>     
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js'></script> 
    <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js'></script>     
    <script src="funciones.js"></script>
</head>
<body>



<div id="fondo">
  <header id="cabecera">
  <h1>CSS3 Ya</h1>
  <p>El objetivo de este tutorial es conocer y practicar con las nuevas propiedades
   que nos presenta el css3. Disponemos de un concepto te�rico, un ejercicio resuelto y la
   vista en ejecuci�n de la p�gina con su hoja de estilo.</p>
   <p>Si no conoce nada de CSS puede visitar primero el tutorial de : <a href="http://www.cssya.com.ar"> 
      CSS Ya</a>.</p>
  </header>
	<div id="temarios">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-4669394804436935";
/* css3 largo */
google_ad_slot = "4371884746";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

    <ul id="submenu">
    <li><a href="detalleconcepto.php?cod=79">1 - Bordes redondeados (border-radius)</a></li><li><a href="detalleconcepto.php?cod=84">2 - Bordes redondeados de alguno de los v�rtices (border-top-left-radius etc.)</a></li><li><a href="detalleconcepto.php?cod=80">3 - Sombras (box-shadow)</a></li><li><a href="detalleconcepto.php?cod=85">4 - Sombras m�ltiples (box-shadow)</a></li><li><a href="detalleconcepto.php?cod=86">5 - Sombras interiores (box-shadow)</a></li><li><a href="detalleconcepto.php?cod=87">6 - Sombras con transparencias (box-shadow)</a></li><li><a href="detalleconcepto.php?cod=94">7 - Sombras de texto (text-shadow)</a></li><li><a href="detalleconcepto.php?cod=88">8 - Transformaciones 2D: rotaci�n (transform:rotate)</a></li><li><a href="detalleconcepto.php?cod=89">9 - Transformaciones 2D: punto de origen  (transform-origin)</a></li><li><a href="detalleconcepto.php?cod=90">10 - Transformaciones 2D: escalado  (transform:scale)</a></li><li><a href="detalleconcepto.php?cod=91">11 - Transformaciones 2D: translaci�n (transform:translate)</a></li><li><a href="detalleconcepto.php?cod=92">12 - Transformaciones 2D: torcer (transform:skew)</a></li><li><a href="detalleconcepto.php?cod=93">13 - Transformaciones 2D: m�ltiples transformaciones en forma simultanea</a></li><li><a href="detalleconcepto.php?cod=95">14 - Opacidad (opacity) </a></li><li><a href="detalleconcepto.php?cod=96">15 - Opacidad (color)</a></li><li><a href="detalleconcepto.php?cod=97">16 - M�ltiples columnas (column-count)</a></li><li><a href="detalleconcepto.php?cod=98">17 - M�ltiples columnas din�micas (column-width)</a></li><li><a href="detalleconcepto.php?cod=99">18 - M�ltiples columnas y su separaci�n (column-gap)</a></li><li><a href="detalleconcepto.php?cod=100">19 - M�ltiples columnas y l�nea separadora (column-rule)</a></li><li><a href="detalleconcepto.php?cod=101">20 - Importar una fuente no disponible en el navegador (@font-face)</a></li><li><a href="detalleconcepto.php?cod=102">21 - Im�genes de fondo (background-image)</a></li><li><a href="detalleconcepto.php?cod=103">22 - Im�genes de fondo en diferentes posiciones (background-position)</a></li><li><a href="detalleconcepto.php?cod=104">23 - Im�genes de fondo (background-size)</a></li><li><a href="detalleconcepto.php?cod=105">24 - Im�genes de fondo (background-origin)</a></li><li><a href="detalleconcepto.php?cod=106">25 - Transiciones de una propiedad (transition)</a></li><li><a href="detalleconcepto.php?cod=107">26 - Transiciones de m�ltiples propiedades (transition)</a></li><li><a href="detalleconcepto.php?cod=108">27 - Transiciones (funciones de transici�n)</a></li><li><a href="detalleconcepto.php?cod=109">28 - Transiciones (tiempo de demora en iniciar la transici�n)</a></li><li><a href="detalleconcepto.php?cod=110">29 - Transiciones (otra sintaxis para hacer lo mismo)</a></li><li><a href="detalleconcepto.php?cod=111">30 - Animaciones (sintaxis b�sica)</a></li><li><a href="detalleconcepto.php?cod=112">31 - Animaciones (animation-iteration-count y animation-direction)</a></li><li><a href="detalleconcepto.php?cod=113">32 - Animaciones (animation-timing-function y animation-delay)</a></li><li><a href="detalleconcepto.php?cod=114">33 - Animaciones (animation-play-state)</a></li><li><a href="detalleconcepto.php?cod=115">34 - Animaciones (definici�n de m�s de 2 keyframes)</a></li><script type="text/javascript"><!--
google_ad_client = "ca-pub-4669394804436935";
/* css3 largo */
google_ad_slot = "4371884746";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

     </div>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-628756-31', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>