<HTML><HEAD>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<script languaje="javascript" src="editor.js" type="text/javascript"></script>
<STYLE>
.editor {
	BORDER-RIGHT: medium none;
	PADDING-RIGHT: 0px; 
	BORDER-TOP: medium none; 
	PADDING-LEFT: 0px; 
	PADDING-BOTTOM: 0px; 
	MARGIN: 0px; 
	BORDER-LEFT: medium none; 
	PADDING-TOP: 0px; 
	BORDER-BOTTOM: medium none;
	WIDTH: 100%; 
	HEIGHT: 100%
}
HTML {
	OVERFLOW: hidden
}
BODY {
	OVERFLOW: hidden
}
</STYLE>
</HEAD>
<BODY class="editor">
<FORM class="editor" id="formulario" name="formulario">
<TEXTAREA class="editor" style="background-color:#F9F7ED" id="paginahtml" name="paginahtml" wrap="hard">
</textarea>
</form>
</BODY>
</html>


