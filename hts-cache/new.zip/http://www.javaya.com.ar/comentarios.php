<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
<title>Comentarios</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="programaci�n, webmaster, tutorial">
<meta name="description" content="El objetivo de este sitio es ser un repositorio de conceptos sobre php html xhtml css mysql javascript">

<style type="text/css">
* {
  margin:0px;
  padding:0px;
}
#contenedor
{

  margin:0px;
  border:1px solid #000;
  line-height:130%;
  background-color:#fff;
  
}
#cabecera
{
  padding:10px;
  color:#fff;
  background-color:#356AA0;
  clear:left;
}
#subcabecera
{
  padding:10px;
  color:#fff;
  background-color:#356AA0;
  clear:left;
  font-family:sans-serif;
  font-size:14px;
}
#columna1
{
  float:left;
  width:170px;
  margin:0;
  padding:0;
}
#columna2
{
  margin-left:190px;
  padding:10px;
  background-color:#fff;
}
#pie {
  padding:10px;
  color:#fff;
  background-color:#356AA0;
  clear:left;
}

#menu {
  font-family: Arial;
  list-style-type:none;  
}

#menu li {
  margin:0px;
}

#menu a {
  display: block;
  padding-bottom: 10px;
  padding-top: 10px;
  width: 99%;
  background-color: #fff;
  text-align:left;
  border-bottom: 1px solid #eeeeee;  
}

#menu a:link, #menu a:visited {
  color: #356aa0;
  text-decoration: none;
  font-family:sans-serif;
  font-size:20px;
  font-style:italic;
  font-weight:bold;
}

#menu a:hover {
  background-color: #fef7b7;
  color: #0061e4;
}

.botones {
  margin: 6px 0pt; padding: 4px 10px; font-size: 130%; font-weight: bold;
}

.enlaceindex {
  text-decoration:none;
  color:#fff;
}

#menuv {
	border-left:1px solid #ACCFE8; 
	border-right:1px solid #ACCFE8; 
	border-top:1px solid #ACCFE8; 
	border-bottom:0px solid #ACCFE8; 
	width: 188px;
	font-style:normal; 
	font-variant:normal; 
	font-weight:normal; 
	font-size:80%; 
	font-family:Trebuchet MS, Arial, Helvetica, sans-serif
}

#menuv ul, li {
	list-style-type: none;
}

#menuv ul {
	margin: 0;
	padding: 0;
}

#menuv li {
	border-bottom: 1px solid #ACCFE8;
}

#menuv a {
	text-decoration: none;
	color: #3366CC;
	background: #F0F7FC;
	display: block;
	padding: 3px 6px;
	width: 176px;
}

#menuv a:hover {
	background: #DBEBF6;
}


#form1 {
  padding:10px;
  color:#000;
  background-color:#f0f0f0;
}
.entradagrande {
  font-size: 1.1em; font-weight: bold;
}
fieldset {padding:10px;width:900px}
.rt {
  width:10%;
  display:inline;
  margin-right:20px;
}
form { font-family: sans-serif; padding:10px; font-size:1.05em }
</style>
<script language="JavaScript">

function ltrim(s) 
{
  return s.replace(/^\s+/, "");
}
function rtrim(s) 
{
  return s.replace(/\s+$/, "");
}
function trim(s) {
return rtrim(ltrim(s));
}

function datosValidos()
{
  var errores='';

  if ((trim(document.getElementById('descripcion').value).length)==0)
    errores+='Escriba algo :)';
  if (errores.length==0)	
    return true;
  else
  {
    alert(errores);
    return false;	
  }
}

function alta()
{
  if (datosValidos())
  {
    document.form1.action='http://www.codigofuenteya.com.ar/altacomentarios.php';
    document.form1.target='_self';
    document.form1.submit();
  }
}
</script>
</head>

<body>
<form method="post" name="form1" id="form1">
<fieldset id="fs">
 <p>El objetivo fundamental de estos sitios web es el aprendizaje de lenguajes de programaci�n. <br>
 Se busca implementar tutoriales f�ciles de seguir y fundamentalmente pr�cticos.<br>
 Cualquier sugerencia puede hacerla por este medio.<br>
 Gracias.</p>
<legend><strong>Comentarios</strong></legend>
<textarea rows="17" cols="110" id="descripcion" name="descripcion"></textarea><br>
<input type="button" value="Confirmar" id="registrar" class="botones" onClick="alta()">
</fieldset>
</form>


</div>
</body>
</html>
