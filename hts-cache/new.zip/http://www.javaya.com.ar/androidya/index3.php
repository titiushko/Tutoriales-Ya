<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
<title>AndroidYa</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="android, java, tutorial, programaci�n">
<meta name="description" content="Tutorial de Android">
<link rel="stylesheet" type="text/css" href="css/estilos.css">
<script type="text/javascript" src="principal.js"></script>
<script language="JavaScript">
window.onload=function(){
if(!NiftyCheck())
    return;
RoundedTop("div#container","#FFF","#e7e7e7");
RoundedBottom("div#container","#FFF","#8395CB");
RoundedTop("ul#nav li","transparent","#FFC");
RoundedTop("div.gradient","#C0CDF2","#B8B8B8");
RoundedBottom("div.gradient","#C0CDF2","#ECECF2");
}
</script>
</head>
<body>

<div id="container">
  <div id="header"> 
    <table>
      <tr> 
        <td width="75%"> <div id="header"> 
            <h1 style="font-size:50px">Android Ya</h1>		
            
          </div></td>
        <td width="25%"> </td>
      </tr>
    </table>

  </div>
<div id="menu">
    <ul id="nav">    
      <li ><a href="index.php">Curso</a></li>
      <li class="active"><a href="index3.php">Enlaces</a></li>

    </ul>
</div>

  <div id="content"> 
    <p>&nbsp;</p><div class="gradient"> 
<br>
      <p> <b>Foro donde consultar sobre Android.</b> <br>
        <a href="http://www.lawebdelprogramador.com/foros/Android/index1.html">www.lawebdelprogramador.com</a><br>
       
      </p>
	     <p> <b></b> <br>
        </p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
   
      
    </div>
  </div> 

<div id="footer">
 Android Ya

</div> 

</div> <!-- close container -->
</body>
</html>
