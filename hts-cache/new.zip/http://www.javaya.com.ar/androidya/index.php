<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
<title>AndroidYa</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="android, java, tutorial, programaci�n">
<meta name="description" content="Tutorial de Android">
<link rel="stylesheet" type="text/css" href="css/estilos.css">
<script type="text/javascript" src="principal.js"></script>
<script language="JavaScript">
window.onload=function(){
if(!NiftyCheck())
    return;
RoundedTop("div#container","#FFF","#e7e7e7");
RoundedBottom("div#container","#FFF","#8395CB");
RoundedTop("ul#nav li","transparent","#FFC");
RoundedTop("div.gradient","#C0CDF2","#B8B8B8");
RoundedBottom("div.gradient","#C0CDF2","#ECECF2");
}
</script>

<style type="text/css">
<!--
#tuto {
 background-color: #c0cdf2;
 margin: 0 auto;
 width: 120px;
 padding: 10px;
 text-align: center;
 -webkit-border-radius: 5px;
 -moz-border-radius: 5px;
 border-radius: 5px;
 -webkit-box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
 -moz-box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
 box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
}



#tuto a:link {
  text-decoration: none;
  color:#00f;
}
#tuto a:visited {
  text-decoration: none;
  color:#00f;  
}

.descarga2 {
background: #F7FABE;
text-align: left;
padding: 5px 20px 5px 45px;
border-top: 2px solid #DFE786;
border-bottom: 2px solid #DFE786;
color:#000000;
margin-left:1.2em;
margin-right:1.2em;
border-radius:4px;
font-size:1.5em;

}
.descarga2 a {
color:#4B4B4B;
text-decoration:none;
border-bottom:1px dotted #444;
}

-->
</style>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js">
  {lang: 'es-419'}
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-628756-30']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>
<body>
<div id="container">
  <div id="header">
  <table width="100%">
      <tr> 
        <td width="45%">
    <div style="float:left">
            <h1 style="font-size:3em;text-shadow: 0px 0px 15px #000;margin-left:20px;margin-bottom:0em">Android Ya</h1>
            <p style="font-size:1.1em;text-shadow: 0px 0px 3px #000;margin-left:20px;color:#fff">
            Un curso de: <a style="text-shadow: 0px 0px 5px #ff0"
            href="http://www.tutorialesya.com.ar" target="_blank">Tutoriales Ya</a></p>
    </div>              
  </td>
<td style="text-align:right">

<div style="float:right">
<div id="tuto">
<strong> Tutoriales</strong>
<br>
 <a href="http://www.javaya.com.ar" target="_blank">Java Ya</a><br>
  <a href="http://www.csharpya.com.ar" target="_blank">C# Ya</a><br>
  <a href="http://www.phpya.com.ar" target="_blank">PHP Ya</a>  
</div>



</div>

</td>
  </tr>
  </table>
  </div>

  <div id="menu">
    <ul id="nav">    
      <li id="home" class="active"><a href="#"> Tutorial</a></li>
      <li id="enlaces"><a href="index3.php">Enlaces</a></li> 	  				  
    </ul>
  </div>

  <div id="content">
  <p style="font-size:1.3em">

El objetivo de este tutorial es iniciarse en la programaci�n de Android.
Se requieren conceptos previos de programaci�n en Java<br>
Se busca ir conociendo los rudimentos b�sicos de la programaci�n en Android presentando los conceptos con ejercicios resueltos e invitando
a la resoluci�n de otros problemas propuesto.

  </p>
<p class="descarga2">Ya se encuentra disponible el nuevo tutorial para aprender android con el nuevo entorno <a target="_blank" href="androidstudioya/">Android Studio propuesto por Google y
que remplaza a Eclipse</a>.
</p>  
  
<div style="padding-left:15px;padding-top:15px">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-4669394804436935";
/* princi arri */
google_ad_slot = "4150651963";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>  
  </div>    
  
    <div class="gradient"> 
	<br>
<ul id="menuop">
<li><a href="detalleconcepto.php?codigo=132&inicio=0">1 - Instalaci�n de Android</a></li><li><a href="detalleconcepto.php?codigo=133&inicio=0">2 - Pasos para crear el primer proyecto Android.</a></li><li><a href="detalleconcepto.php?codigo=134&inicio=0">3 - Captura del clic de un bot�n</a></li><li><a href="detalleconcepto.php?codigo=135&inicio=0">4 - Controles RadioGroup y RadioButton</a></li><li><a href="detalleconcepto.php?codigo=136&inicio=0">5 - Control CheckBox</a></li><li><a href="detalleconcepto.php?codigo=137&inicio=0">6 - Control Spinner</a></li><li><a href="detalleconcepto.php?codigo=138&inicio=0">7 - Control ListView</a></li><li><a href="detalleconcepto.php?codigo=139&inicio=0">8 - Control ImageButton</a></li><li><a href="detalleconcepto.php?codigo=140&inicio=0">9 - Lanzar un segundo "Activity"</a></li><li><a href="detalleconcepto.php?codigo=141&inicio=0">10 - Lanzar un segundo "Activity" y pasar par�metros.</a></li><li><a href="detalleconcepto.php?codigo=142&inicio=0">11 - Almacenamiento de datos mediante la clase SharedPreferences</a></li><li><a href="detalleconcepto.php?codigo=143&inicio=0">12 - Almacenamiento de datos en un archivo de texto en la memoria interna.</a></li><li><a href="detalleconcepto.php?codigo=144&inicio=0">13 - Almacenamiento de datos en un archivo de texto localizado en una tarjeta SD</a></li><li><a href="detalleconcepto.php?codigo=145&inicio=0">14 - Almacenamiento en una base de datos SQLite</a></li><li><a href="detalleconcepto.php?codigo=159&inicio=0">15 - Instalaci�n del programa Android en un dispositivo real</a></li><li><a href="detalleconcepto.php?codigo=146&inicio=0">16 - Layout (LinearLayout)</a></li><li><a href="detalleconcepto.php?codigo=147&inicio=0">17 - Layout (TableLayout)</a></li><li><a href="detalleconcepto.php?codigo=148&inicio=0">18 - Layout (RelativeLayout)</a></li><li><a href="detalleconcepto.php?codigo=149&inicio=0">19 - Layout (FrameLayout)</a></li><li><a href="detalleconcepto.php?codigo=150&inicio=0">20 - Layout (ScrollView y LinearLayout)</a></li></ul>
<div>
<center><div style="padding:10px"><tr>

<center><div style="padding:10px"><tr><span></span><span style="font-weight:bold;font-size:22px;padding:7px;background-color:#ffff00">1</span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/androidya/index.php?inicio=20">2</A></span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/androidya/index.php?inicio=40">3</A></span></tr></div></center>

</div></center>


</div>

<center>
<script type="text/javascript"><!--
google_ad_client = "pub-4669394804436935";
/* 728x90, creado 11/08/10 largo */
google_ad_slot = "7781921262";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>  
</center>

     </div>
  </div>

<div id="footer">
 Android Ya

</div> 

</div>

</body>
</html>
