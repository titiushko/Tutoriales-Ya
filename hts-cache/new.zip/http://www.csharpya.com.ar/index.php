<!DOCTYPE HTML> 
<html>
<head>
<title>C# Ya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">    
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="c#,c sharp, tutorial, programaci�n">
<meta name="description" content="Tutorial de C#">
<link rel="stylesheet" type="text/css" href="css/estilos4.css">
<script type="text/javascript" src="principal.js"></script>
<script language="JavaScript">
window.onload=function(){
if(!NiftyCheck())
    return;
RoundedTop("div#container","#FFF","#e7e7e7");
RoundedBottom("div#container","#FFF","#8395CB");
RoundedTop("ul#nav li","transparent","#FFC");
RoundedTop("div.gradient","#C0CDF2","#B8B8B8");
RoundedBottom("div.gradient","#C0CDF2","#ECECF2");
}
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-628756-29']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<style type="text/css">
<!--

#tuto {
 background-color: #c0cdf2;
 margin: 0 auto;
 width: 120px;
 padding: 10px;
 text-align: center;
 -webkit-border-radius: 5px;
 -moz-border-radius: 5px;
 border-radius: 5px;
 -webkit-box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
 -moz-box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
 box-shadow: rgba(0,0,0,0.2) 0px 1px 3px;
}



#tuto a:link {
  text-decoration: none;
  color:#00f;
}
#tuto a:visited {
  text-decoration: none;
  color:#00f;  
}


-->
</style>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js">
  {lang: 'es-419'}
</script>
</head>
<body>
<div id="container">
  <div id="header">
  <table width="100%">
      <tr> 
        <td width="45%">
    <div style="float:left">
            <h1 style="font-size:4em;text-shadow: 0px 0px 15px #000;margin-left:20px;margin-bottom:0em">C# Ya</h1>
            <p style="font-size:1.1em;text-shadow: 0px 0px 3px #000;margin-left:20px;color:#fff">
            Un curso de: <a style="text-shadow: 0px 0px 5px #ff0"
            href="http://www.tutorialesya.com.ar" target="_blank">Tutoriales Ya</a></p>
    </div>        

  </td>
<td align="right">

<div style="float:right">
<div id="tuto">
<strong> Tutoriales</strong>
<br>
<a href="http://www.javascriptya.com.ar/nodejsya/" target="_blank">Node.js Ya</a><br>
 <a href="http://www.javaya.com.ar" target="_blank">Java Ya</a><br>
  <a href="http://www.csharpya.com.ar" target="_blank">C# Ya</a><br>
  <a href="http://www.tutorialesya.com.ar/cmasmasya/" target="_blank">C++ Ya</a>    
</div>

<br><span style="text-align:right"><g:plusone></g:plusone></span>
<br>
<a style="font-size:9px;margin-right:11px" href="politicas.htm">Pol�ticas de privacidad.</a>
</div>

</td>


  </tr>
  </table>
  </div>

  <div id="menu">

    <ul id="nav">    
      <li id="home" class="active"><a href="#"> Tutorial</a></li>
      <li id="enlaces"><a href="index3.php">Enlaces</a></li>       
      <li id="who"><a href="index2.php?op=2">Acerca de...</a></li>       
    </ul>
  </div>

  <div id="content">
  <p style="font-size:1.3em">
El objetivo de este tutorial es iniciarse en el arte de la programaci�n desde cero.
No se requieren conceptos previos de programaci�n y se hace una introducci�n gradual en esta ciencia.<br>
Se utilizan en un principio el planteo de "Diagramas de Flujo" para la resoluci�n de problemas y su posterior codificaci�n 
con el lenguaje C#.<br>
Se busca ir conociendo los rudimentos b�sicos de la programaci�n presentando los conceptos con ejercicios resueltos e invitando
a la resoluci�n de otros problemas propuesto.

  </p>
  <div style="padding-left:15px">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-4669394804436935";
/* princi arri */
google_ad_slot = "4150651963";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>  
  </div>
    <div class="gradient"> 
	<br>
<ul id="menuop">
<li><a href="detalleconcepto.php?codigo=125&inicio=0">1 - Objetivos del curso y nociones b�sicas de programaci�n</a></li><li><a href="detalleconcepto.php?codigo=126&inicio=0">2 - Creaci�n de un proyecto en C#</a></li><li><a href="detalleconcepto.php?codigo=127&inicio=0">3 - Codificaci�n del diagrama de flujo en C#</a></li><li><a href="detalleconcepto.php?codigo=128&inicio=0">4 - Errores sint�cticos y l�gicos</a></li><li><a href="detalleconcepto.php?codigo=129&inicio=0">5 - Estructura de programaci�n secuencial</a></li><li><a href="detalleconcepto.php?codigo=130&inicio=0">6 - Estructuras condicionales simples y compuestas</a></li><li><a href="detalleconcepto.php?codigo=131&inicio=0">7 - Estructuras condicionales anidadas</a></li><li><a href="detalleconcepto.php?codigo=132&inicio=0">8 - Condiciones compuestas con operadores l�gicos</a></li><li><a href="detalleconcepto.php?codigo=133&inicio=0">9 - Estructura repetitiva while</a></li><li><a href="detalleconcepto.php?codigo=134&inicio=0">10 - Estructura repetitiva for</a></li><li><a href="detalleconcepto.php?codigo=135&inicio=0">11 - Estructura repetitiva do while</a></li><li><a href="detalleconcepto.php?codigo=136&inicio=0">12 - Cadenas de caracteres</a></li><li><a href="detalleconcepto.php?codigo=137&inicio=0">13 - Declaraci�n de una clase y definici�n de objetos.</a></li><li><a href="detalleconcepto.php?codigo=138&inicio=0">14 - Declaraci�n de m�todos</a></li><li><a href="detalleconcepto.php?codigo=139&inicio=0">15 - Estructura de datos tipo vector</a></li><li><a href="detalleconcepto.php?codigo=140&inicio=0">16 - Vector (Tama�o de un vector)</a></li><li><a href="detalleconcepto.php?codigo=141&inicio=0">17 - Vectores paralelos</a></li><li><a href="detalleconcepto.php?codigo=142&inicio=0">18 - Vectores (mayor y menor elemento)</a></li><li><a href="detalleconcepto.php?codigo=143&inicio=0">19 - Vectores (ordenamiento)</a></li><li><a href="detalleconcepto.php?codigo=144&inicio=0">20 - Vectores (ordenamiento con vectores paralelos)</a></li></ul>
<div>
<center><div style="padding:10px"><tr>

<center><div style="padding:10px"><tr><span></span><span style="font-weight:bold;font-size:22px;padding:7px;background-color:#ffff00">1</span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/index.php?inicio=20">2</A></span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/index.php?inicio=40">3</A></span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/index.php?inicio=60">4</A></span><span style="font-weight:bold;font-size:22px;padding:7px"><A href="/index.php?inicio=80">5</A></span></tr></div></center>

</div></center>


</div>

  <center>
  <center>
<script type="text/javascript"><!--
google_ad_client = "pub-4669394804436935";
/* 728x90, creado 11/08/10 largo */
google_ad_slot = "7781921262";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>  
</center>
  
</center>

     </div>
  </div>

<div id="footer">
 C# Ya

</div> <!--close footer -->

</div>
</body>
</html>
