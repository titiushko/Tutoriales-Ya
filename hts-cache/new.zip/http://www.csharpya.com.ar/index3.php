<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
<title>C# Ya</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="c#,c sharp, tutorial, programaci�n">
<meta name="description" content="Tutorial de C#">
<link rel="stylesheet" type="text/css" href="css/estilos4.css">
<script type="text/javascript" src="principal.js"></script>
<script language="JavaScript">
window.onload=function(){
if(!NiftyCheck())
    return;
RoundedTop("div#container","#FFF","#e7e7e7");
RoundedBottom("div#container","#FFF","#8395CB");
RoundedTop("ul#nav li","transparent","#FFC");
RoundedTop("div.gradient","#C0CDF2","#B8B8B8");
RoundedBottom("div.gradient","#C0CDF2","#ECECF2");
}
</script>
</head>
<body>
<div id="container">
  <div id="header"> 
    <table>
      <tr> 
        <td width="75%"> <div id="header"> 
            <h1>C# Ya</h1>
          </div></td>
        <td width="25%"> </td>
      </tr>
    </table>

  </div>
<div id="menu">
    <ul id="nav">    
      <li ><a href="index.php">Tutorial</a></li>
      <li class="active"><a href="index3.php">Enlaces</a></li>
      <li ><a href="index2.php">Acerca de...</a></li> 
    </ul>
</div>
<!-- star of main content -->
  <div id="content"> 
    <p>&nbsp;</p><div class="gradient"> 
<br>
      <p> <b>Foro donde consultar sobre C#.</b> <br>
        <a href="http://www.lawebdelprogramador.com/news/new.php?id=237&texto=Visual%20CSharp%20.NET">www.lawebdelprogramador.com</a><br>
       
      </p>
	     <p> <b></b> <br>
        </p>
        <p></p>
 <br><br>  <br>  <br>  <br>  <br>  <br>  <br>    
 <br><br>  <br>  <br>  <br>  <br>  <br>  <br>         
    </div>
  </div> 

<div id="footer">
 
</div> <!--close footer -->

</div> <!-- close container -->
</body>
</html>
