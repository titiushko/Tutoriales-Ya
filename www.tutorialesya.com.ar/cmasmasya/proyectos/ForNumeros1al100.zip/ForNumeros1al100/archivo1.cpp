#include<iostream>

using namespace std;

void main()
{
	int f;
	for (f = 1; f <= 100; f++)
	{
		cout << f;
		cout << "-";
	}
	cin.get();
}