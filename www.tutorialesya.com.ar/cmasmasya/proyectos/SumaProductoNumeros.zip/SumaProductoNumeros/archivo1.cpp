#include<iostream>

using namespace std;

void main()
{
	int num1, num2, num3, num4, suma, producto;
	cout << "Ingrese primer valor:";
	cin >> num1;
	cout << "Ingrese segundo valor:";
	cin >> num2;
	cout << "Ingrese tercer valor:";
	cin >> num3;
	cout << "Ingrese cuarto valor:";
	cin >> num4;
	suma = num1 + num2;
	producto = num3 * num4;
	cout << "La suma de los dos primero valores es:";
	cout << suma;
	cout << "\n";
	cout << "El producto del tercer y cuarto valor es:";
	cout << producto;
	cin.get();
	cin.get();
}
