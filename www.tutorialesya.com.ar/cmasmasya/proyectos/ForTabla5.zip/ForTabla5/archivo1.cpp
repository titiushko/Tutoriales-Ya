
#include<iostream>

using namespace std;

void main()
{
	int f;
	for (f = 5; f <= 50; f = f + 5)
	{
		cout << f;
		cout << "-";
	}
	cin.get();
}

