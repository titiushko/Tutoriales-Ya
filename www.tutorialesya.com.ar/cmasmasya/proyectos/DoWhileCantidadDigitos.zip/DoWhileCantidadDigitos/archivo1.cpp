#include<iostream>

using namespace std;

void main()
{
	int valor;
	do {
		cout << "Ingrese un valor entre 0 y 999 (0 finaliza):";
		cin >> valor;
		if (valor >= 100)
		{
			cout << "Tiene 3 d�gitos.";
		}
		else
		{
			if (valor >= 10)
			{
				cout << "Tiene 2 d�gitos.";
			}
			else
			{
				cout << "Tiene 1 d�gito.";
			}
		}
		cout << "\n";
	} while (valor != 0);
}