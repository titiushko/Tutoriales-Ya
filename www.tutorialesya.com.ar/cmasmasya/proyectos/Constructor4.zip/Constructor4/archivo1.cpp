#include<iostream>

using namespace std;

class EmpleadoFabrica {
private:
	char nombre[40];
	float sueldo;
public:
	EmpleadoFabrica();
	void imprimir();
	void pagaImpuestos();
};

EmpleadoFabrica::EmpleadoFabrica()
{
	cout << "Ingrese el nombre del empleado:";
	cin.getline(nombre, 40);
	cout << "Ingrese su sueldo:";
	cin >> sueldo;
}

void EmpleadoFabrica::imprimir()
{
	cout << "Nombre:" << nombre << "\n";
	cout << "Sueldo" << sueldo << "\n\n";
}

void EmpleadoFabrica::pagaImpuestos()
{
	if (sueldo > 3000)
	{
		cout << "Debe abonar impuestos";
	}
	else
	{
		cout << "No paga impuestos";
	}
	cin.get();
	cin.get();
}

void main()
{
	EmpleadoFabrica empleado1;
	empleado1.imprimir();
	empleado1.pagaImpuestos();
}