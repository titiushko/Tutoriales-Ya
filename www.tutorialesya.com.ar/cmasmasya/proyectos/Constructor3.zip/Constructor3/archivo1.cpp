#include<iostream>

using namespace std;

class Moneda {
private:
	int valor;
public:
	Moneda(int v);
	void imprimir();
};

Moneda::Moneda(int v)
{
	valor = v;
}

void Moneda::imprimir()
{
	cout << "Valor de la moneda:" << valor << "\n";
}

void main()
{
	Moneda moneda1(5);
	Moneda moneda2(50);
	moneda1.imprimir();
	moneda2.imprimir();
	cin.get();
}