#include <iostream>

using namespace std;

class Recursividad {
public:
	void imprimir(int x);
};

void Recursividad::imprimir(int x)
{
	if (x > 0)
	{
		cout << x << "-";
		imprimir(x - 1);
	}
}

void main()
{
	Recursividad *recu = new Recursividad();
	recu->imprimir(5);
	delete recu;
	cin.get();
}