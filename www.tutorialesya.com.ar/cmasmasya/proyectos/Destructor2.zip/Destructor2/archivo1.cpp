#include <iostream>

using namespace std;

class Sumatoria {
private:
	int suma;
public:
	void cargar();
	~Sumatoria();
};


void Sumatoria::cargar()
{
	int valor;
	suma = 0;
	do {
		cout << "Ingrese un valor (0 para finalizar):";
		cin >> valor;
		suma = suma + valor;
	} while (valor != 0);
}

Sumatoria::~Sumatoria()
{
	cout << "La suma de todos los valores ingresados es:";
	cout << suma;
	cin.get();
	cin.get();
}


void main()
{
	Sumatoria sumatoria1;
	sumatoria1.cargar();
}

