#include<iostream>

using namespace std;

void main()
{
	int cant1, cant2, cant3, suma;
	float peso;
	cant1 = 0;
	cant2 = 0;
	cant3 = 0;
	do {
		cout << "Ingrese el peso de la pieza (0 pera finalizar):";
		cin >> peso;
		if (peso > 10.2)
		{
			cant1++;
		}
		else
		{
			if (peso >= 9.8)
			{
				cant2++;
			}
			else
			{
				if (peso > 0)
				{
					cant3++;
				}
			}
		}
	} while (peso != 0);
	suma = cant1 + cant2 + cant3;
	cout << "Piezas aptas:";
	cout << cant2;
	cout << "\n";
	cout << "Piezas con un peso superior a 10.2:";
	cout << cant1;
	cout << "\n";
	cout << "Piezas con un peso inferior a 9.8:";
	cout << cant3;
	cin.get();
	cin.get();
}