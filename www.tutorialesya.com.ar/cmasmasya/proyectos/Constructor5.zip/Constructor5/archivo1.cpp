#include<iostream>

using namespace std;

class Operaciones {
private:
	int valor1, valor2;
public:
	Operaciones(int v1, int v2);
	void sumar();
	void restar();
	void multiplicar();
	void dividir();
};

Operaciones::Operaciones(int v1, int v2)
{
	valor1 = v1;
	valor2 = v2;
}

void Operaciones::sumar()
{
	int suma;
	suma = valor1 + valor2;
	cout << "La suma es:" << suma << "\n";
}

void Operaciones::restar()
{
	int resta;
	resta = valor1 - valor2;
	cout << "La resta es:" << resta << "\n";
}

void Operaciones::multiplicar()
{
	int multi;
	multi = valor1*valor2;
	cout << "El producto es:" << multi << "\n";
}

void Operaciones::dividir()
{
	int division;
	division = valor1 / valor2;
	cout << "La division es:" << division << "\n";
}

void main()
{
	Operaciones operaciones1(100, 50);
	operaciones1.sumar();
	operaciones1.restar();
	operaciones1.multiplicar();
	operaciones1.dividir();
	cin.get();
}