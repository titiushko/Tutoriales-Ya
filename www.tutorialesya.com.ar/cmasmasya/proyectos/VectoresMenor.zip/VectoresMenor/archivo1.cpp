#include<iostream>

using namespace std;

class BusquedaMenor {
private:
	int vec[5];
	int menor;
public:
	void cargar();
	void menorElemento();
	void repiteMenor();
};

void BusquedaMenor::cargar()
{
	for (int f = 0; f < 5; f++)
	{
		cout << "Ingrese componente:";
		cin >> vec[f];
	}
}

void BusquedaMenor::menorElemento()
{
	menor = vec[0];
	for (int f = 1; f < 5; f++)
	{
		if (vec[f] < menor)
		{
			menor = vec[f];
		}
	}
	cout << "El elemento menor es:";
	cout << menor;
	cout << "\n";
}

void BusquedaMenor::repiteMenor()
{
	int cant = 0;
	for (int f = 0; f < 5; f++)
	{
		if (vec[f] == menor)
		{
			cant++;
		}
	}
	if (cant > 1)
	{
		cout << "Se repite el menor en el vector.";
	}
	else
	{
		cout << "No se repite el menor en el vector.";
	}
	cin.get();
	cin.get();
}

void main()
{
	BusquedaMenor bm;
	bm.cargar();
	bm.menorElemento();
	bm.repiteMenor();
}