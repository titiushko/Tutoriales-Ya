#include<iostream>

using namespace std;

void main()
{
	float f1, f2;
	float *pf;
	pf = &f1;
	*pf = 10.5;
	pf = &f2;
	*pf = 20.2;
	cout << f1;
	cout << "\n";
	cout << f2;
	cin.get();
}