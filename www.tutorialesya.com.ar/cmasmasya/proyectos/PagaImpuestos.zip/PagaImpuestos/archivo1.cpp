#include <iostream>

using namespace std;

void main()
{
	float sueldo;
	cout << "Ingrese el sueldo";
	cin >> sueldo;
	if (sueldo>3000)
	{
		cout << "Esta persona debe abonar impuestos";
	}
	cin.get();
	cin.get();
}