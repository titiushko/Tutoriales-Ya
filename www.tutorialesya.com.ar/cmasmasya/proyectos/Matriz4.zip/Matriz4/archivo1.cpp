#include<iostream>

using namespace std;

class Matriz4 {
private:
	int mat[2][5];
public:
	void cargar();
	void imprimir();
};


void Matriz4::cargar()
{
	cout << "Carga de la matriz por columna:" << "\n";
	for (int c = 0; c < 5; c++)
	{
		for (int f = 0; f < 2; f++)
		{
			cout << "Ingrese componente  de la fila " << f << " y la columna " << c << " :";
			cin >> mat[f][c];
		}
	}
}

void Matriz4::imprimir()
{
	for (int f = 0; f < 2; f++)
	{
		for (int c = 0; c < 5; c++)
		{
			cout << mat[f][c] << " ";
		}
		cout << "\n";
	}
	cin.get();
	cin.get();
}

void main()
{
	Matriz4 m;
	m.cargar();
	m.imprimir();
}