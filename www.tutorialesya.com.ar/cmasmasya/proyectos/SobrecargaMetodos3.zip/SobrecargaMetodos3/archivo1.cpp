#include <iostream>

using namespace std;

class Vector {
	int vec[5];
public:
	void cargar();
	void imprimir();
	void imprimir(int hasta);
	void imprimir(int desde, int hasta);
};

void Vector::cargar()
{
	for (int f = 0; f<5; f++)
	{
		cout << "Ingrese componente:";
		cin >> vec[f];
	}
}

void Vector::imprimir()
{
	for (int f = 0; f<5; f++)
	{
		cout << vec[f] << "-";
	}
	cout << "\n\n";
}

void Vector::imprimir(int hasta)
{
	for (int f = 0; f <= hasta; f++)
	{
		cout << vec[f] << "-";
	}
	cout << "\n\n";
}

void Vector::imprimir(int desde, int hasta)
{
	for (int f = desde; f <= hasta; f++)
	{
		cout << vec[f] << "-";
	}
	cout << "\n\n";
}


void main()
{
	Vector v1;
	v1.cargar();
	v1.imprimir();
	v1.imprimir(2);
	v1.imprimir(2, 4);
	cin.get();
	cin.get();
}