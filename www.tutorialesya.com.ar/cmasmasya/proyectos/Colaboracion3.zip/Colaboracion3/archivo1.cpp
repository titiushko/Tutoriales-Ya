#include<iostream>

using namespace std;

class Socio {
	char nombre[40];
	int antiguedad;
public:
	Socio();
	void imprimir();
	int retornarAntiguedad();
};

class Club {
	Socio socio1, socio2, socio3;
public:
	void mayorAntiguedad();
};

Socio::Socio()
{
	cout << "Ingrese nombre:";
	cin.getline(nombre, 40);
	cout << "Ingrese antiguedad:";
	cin >> antiguedad;
	cin.get();
}

void Socio::imprimir()
{
	cout << "Nombre:" << nombre << "  Antiguedad:" << antiguedad << "\n\n";
}

int Socio::retornarAntiguedad()
{
	return antiguedad;
}


void Club::mayorAntiguedad() 
{
	cout << "Socio con mayor antiguedad\n";
	if (socio1.retornarAntiguedad() > socio2.retornarAntiguedad() &&
		socio1.retornarAntiguedad() > socio3.retornarAntiguedad()) 
	{
		socio1.imprimir();
	}
	else 
	{
		if (socio2.retornarAntiguedad() > socio3.retornarAntiguedad()) 
		{
			socio2.imprimir();
		}
		else 
		{
			socio3.imprimir();
		}
	}
}


void main()
{
	Club club1;
	club1.mayorAntiguedad();
	cin.get();
}
