

#include<iostream>

using namespace std;

class Punto {
	int x, y;
public:
	Punto();
	Punto(int vx, int vy);
	void imprimir();
};

Punto::Punto()
{
	x = 0;
	y = 0;
}

Punto::Punto(int vx, int vy)
{
	x = vx;
	y = vy;
}

void Punto::imprimir()
{
	cout << "x:" << x << " y:" << y;
	cout << "\n\n";
}

void main()
{
	Punto p1;
	p1.imprimir();
	Punto p2(30, 2);
	p2.imprimir();
	cin.get();
}
