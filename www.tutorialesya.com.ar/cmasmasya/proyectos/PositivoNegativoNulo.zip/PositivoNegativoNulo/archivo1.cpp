#include<iostream>

using namespace std;

void main()
{
	int num;
	cout << "Ingrese un valor:";
	cin >> num;
	if (num == 0)
	{
		cout << "Se ingres� el cero";
	}
	else
	{
		if (num > 0)
		{
			cout << "Se ingres� un valor positivo";
		}
		else
		{
			cout << "Se ingres� un valor negativo";
		}
	}
	cin.get();
	cin.get();
}

