#include<iostream>

using namespace std;

void main()
{
	char mes1[20] = "enero";
	char mes2[20] = "febrero";
	cout << mes1;
	cout << "\n";
	cout << mes2;
	cin.get();
}