#include<iostream>

using namespace std;

class NotasAlumnos {
private:
	char nombres[4][40];
	int notas[4];
public:
	void cargar();
	void imprimirEstado();
	void cantidadAlumnosMuyBueno();
};

void NotasAlumnos::cargar()
{
	for (int f = 0; f < 4; f++)
	{
		cout << "Ingrese el nombre del alumno:";
		cin.getline(nombres[f], 40);
		cout << "Ingrese la nota:";
		cin >> notas[f];
		cin.get();
	}
}

void NotasAlumnos::imprimirEstado()
{
	for (int f = 0; f < 4; f++)
	{
		cout << nombres[f];
		cout << "-";
		cout << notas[f];
		cout << "-";
		if (notas[f] >= 8)
		{
			cout << "Muy bueno";
		}
		else
		{
			if (notas[f] >= 4)
			{
				cout << "Bueno";
			}
			else
			{
				cout << "Insuficiente";
			}
		}
		cout << "\n";
	}
}

void NotasAlumnos::cantidadAlumnosMuyBueno()
{
	int cantidad = 0;
	for (int f = 0; f < 4; f++)
	{
		if (notas[f] >= 8)
		{
			cantidad++;
		}
	}
	cout << "Cantidad de alumnos muy buenos:";
	cout << cantidad;
}


void main()
{
	NotasAlumnos notaslumnos1;
	notaslumnos1.cargar();
	notaslumnos1.imprimirEstado();
	notaslumnos1.cantidadAlumnosMuyBueno();
	cin.get();
}