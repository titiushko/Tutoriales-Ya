#include<iostream>

using namespace std;

class Tabla {
private:
	int valor;
public:
	Tabla();
	void imprimir();
	~Tabla();
};


Tabla::Tabla()
{
	cout << "Ingrese un valor:";
	cin >> valor;
}

void Tabla::imprimir()
{
	for (int f = valor; f <= valor * 10; f = f + valor)
	{
		cout << f << "-";
	}
	cout << "\n";
}

Tabla::~Tabla()
{
	cout << "Gracias por utilizar este programa.";
	cin.get();
	cin.get();
}

void main()
{
	Tabla tabla1;
	tabla1.imprimir();
}
