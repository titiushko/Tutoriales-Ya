#include<iostream>

using namespace std;

void main()
{
	int num1, num2, suma, producto;
	cout << "Ingrese primer valor:";
	cin >> num1;
	cout << "Ingrese segundo valor:";
	cin >> num2;
	suma = num1 + num2;
	producto = num1 * num2;
	cout << "La suma de los dos valores es:";
	cout << suma;
	cout << "\n";
	cout << "El producto de los dos valores es:";
	cout << producto;
	cin.get();
	cin.get();
}