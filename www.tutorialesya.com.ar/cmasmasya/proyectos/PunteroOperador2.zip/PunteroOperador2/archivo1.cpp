#include<iostream>

using namespace std;

class Vector {
	int vec[5];
public:
	void cargar();
	void imprimir();
};

void Vector::cargar()
{
	for (int f = 0; f < 5; f++)
	{
		cout << "Ingrese componente:";
		cin >> vec[f];
	}
}

void Vector::imprimir()
{
	int *pe;
	pe = vec;
	for (int f = 0; f < 5; f++)
	{
		cout << *pe;
		pe++;
		cout << "-";
	}
}

void main()
{
	Vector vector1;
	vector1.cargar();
	vector1.imprimir();
	cin.get();
	cin.get();
}

