

#include<iostream>

using namespace std;

void main()
{
	int f, lado1, lado2, lado3, cant1, cant2, cant3, n;
	cant1 = 0;
	cant2 = 0;
	cant3 = 0;
	cout << "Ingrese la cantidad de tri�ngulos:";
	cin >> n;
	for (f = 1; f <= n; f++)
	{
		cout << "Ingrese lado 1:";
		cin >> lado1;
		cout << "Ingrese lado 2:";
		cin >> lado2;
		cout << "Ingrese lado 3:";
		cin >> lado3;
		if (lado1 == lado2 && lado1 == lado3)
		{
			cout << "Es un tri�ngulo equilatero.";
			cout << "\n";
			cant1++;
		}
		else
		{
			if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
			{
				cout << "Es un tri�ngulo is�sceles.";
				cout << "\n";
				cant2++;
			}
			else
			{
				cant3++;
				cout << "Es un tri�ngulo escaleno.";
				cout << "\n";
			}
		}
	}
	cout << "Cantidad de tri�ngulos equilateros:";
	cout << cant1;
	cout << "\n";
	cout << "Cantidad de tri�ngulos is�sceles:";
	cout << cant2;
	cout << "\n";
	cout << "Cantidad de tri�ngulos escalenos:";
	cout << cant3;
	cout << "\n";
	if (cant1 < cant2 && cant1 < cant3)
	{
		cout << "Hay menor cantidad de tri�ngulos equilateros.";
	}
	else
	{
		if (cant2 < cant3)
		{
			cout << "Han menor cantidad de tri�ngulos is�sceles";
		}
		else
		{
			cout << "Han menor cantidad de tri�ngulos escalenos";
		}
	}
	cin.get();
	cin.get();
}