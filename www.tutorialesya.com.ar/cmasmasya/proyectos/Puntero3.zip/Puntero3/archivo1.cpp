#include<iostream>

using namespace std;

void main()
{
	int x1 = 5;
	int x2 = 10;
	int x3 = 15;
	int *pe;
	pe = &x1;
	cout << *pe;
	cout << "\n";
	pe = &x2;
	cout << *pe;
	cout << "\n";
	pe = &x3;
	cout << *pe;
	cin.get();
}