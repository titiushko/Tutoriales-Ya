package androidya.proyecto030;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class Proyecto030Activity extends Activity {
	EditText et1;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        et1=(EditText)findViewById(R.id.editText1);
        registerForContextMenu(et1);        
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo)
    {
    	menu.setHeaderTitle("Elija el color de fondo:");    	
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.menu1, menu);
    }    
    
    @Override
    public boolean onContextItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
    	case R.id.item1:et1.setBackgroundColor(Color.rgb(255, 0, 0)) ;
    	break;
    	case R.id.item2:et1.setBackgroundColor(Color.rgb(0, 255, 0)) ; 
    	break;
    	case R.id.item3:et1.setBackgroundColor(Color.rgb(0, 0, 255)) ; 
    	break;                
    	}
    	return true;
    }    
}