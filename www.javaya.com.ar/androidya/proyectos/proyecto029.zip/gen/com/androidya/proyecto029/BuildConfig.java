/** Automatically generated file. DO NOT MODIFY */
package com.androidya.proyecto029;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}