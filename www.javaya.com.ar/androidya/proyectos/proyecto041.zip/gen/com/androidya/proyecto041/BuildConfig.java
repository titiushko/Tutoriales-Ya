/** Automatically generated file. DO NOT MODIFY */
package com.androidya.proyecto041;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}