package androidya.proyecto021;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;

public class Proyecto031Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle("Importante");
    	builder.setMessage("Este es un programa solo de prueba y no la versi�n completa");
    	builder.setPositiveButton("OK",null);
    	builder.create();
    	builder.show();        
    }
}