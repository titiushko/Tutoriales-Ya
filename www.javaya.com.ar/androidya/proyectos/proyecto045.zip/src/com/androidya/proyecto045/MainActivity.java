package com.androidya.proyecto045;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends Activity {
	EditText et1, et2;
	RadioButton rb1, rb2;
	TextView tv1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		et1 = (EditText) findViewById(R.id.editText1);
		et2 = (EditText) findViewById(R.id.editText2);
		rb1 = (RadioButton) findViewById(R.id.radio0);
		rb2 = (RadioButton) findViewById(R.id.radio1);
		tv1 = (TextView) findViewById(R.id.textView1);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	public void operar(View v) {
		int v1 = Integer.parseInt(et1.getText().toString());
		int v2 = Integer.parseInt(et2.getText().toString());
		if (rb1.isChecked()) {
			int suma = v1 + v2;
			tv1.setText(String.valueOf(suma));
		} else if (rb2.isChecked()) {
			int resta = v1 - v2;
			tv1.setText(String.valueOf(resta));
		}
	}

}
