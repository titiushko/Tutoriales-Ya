/** Automatically generated file. DO NOT MODIFY */
package com.javaya.proyecto007;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}