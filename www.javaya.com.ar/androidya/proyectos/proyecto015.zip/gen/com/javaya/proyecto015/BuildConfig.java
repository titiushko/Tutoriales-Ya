/** Automatically generated file. DO NOT MODIFY */
package com.javaya.proyecto015;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}