package ar.com.tutorialesya.proyecto015;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {

    private EditText et1;
    private TextView tv2, tv3;
    private Button b1;
    private int numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = (EditText) findViewById(R.id.editText);
        tv2 = (TextView) findViewById(R.id.textView2);
        tv3 = (TextView) findViewById(R.id.textView3);
        SharedPreferences prefe = getSharedPreferences("datos", Context.MODE_PRIVATE);
        String v = String.valueOf(prefe.getInt("puntos", 0));
        tv2.setText(v);
        numero = 1 + (int) (Math.random() * 50);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void verificar(View v) {
        int valor = Integer.parseInt(et1.getText().toString());
        if (numero == valor) {
            int puntosactual = Integer.parseInt(tv2.getText()
                    .toString());
            puntosactual++;
            tv2.setText(String.valueOf(puntosactual));
            tv3.setText("Muy bien ganó. Ahora pienso otro numero");
            et1.setText("");
            SharedPreferences preferencias =getSharedPreferences("datos", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferencias.edit();
            editor.putInt("puntos", puntosactual);
            editor.commit();
        } else {
            if (valor > numero) {
                tv3.setText("Ingreso un numero mayor al que penso la maquina.");
            } else {
                tv3.setText("Ingreso un numero menor al que penso la maquina.");
            }
        }
    }
}
